 /* An exception to throw when encountering an unexpected cycle.
 */

public class TooManyPlayersException extends Exception {

}
